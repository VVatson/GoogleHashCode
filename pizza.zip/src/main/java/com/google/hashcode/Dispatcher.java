package com.google.hashcode;

/**
 * Created by Andrey on 01.03.2018.
 */
public interface Dispatcher {

    Drive getNewRide(VehicleState vehicleState);
}
